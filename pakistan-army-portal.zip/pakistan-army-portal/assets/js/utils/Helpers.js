class Helpers {
    static formatTime(elapsed) {
        const hours = Math.floor(elapsed / 3600000);
        const minutes = Math.floor((elapsed % 3600000) / 60000);
        const seconds = Math.floor((elapsed % 60000) / 1000);
        
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    static scrollToSection(sectionId) {
        console.log('Scrolling to:', sectionId);
    }

    static generateScenario() {
        return {
            distance: Math.random() * 1000 + 300,
            speed: Math.random() * 40 + 10,
            direction: Math.random() * 360,
            unitSize: Math.floor(Math.random() * 5) + 2,
            terrain: 'urban',
            timeOfDay: new Date().getHours(),
            type: 'enemy'
        };
    }

    static getIconConfig(threatLevel, type) {
        let iconColor, iconSymbol;
        
        if (type === 'enemy') {
            switch(threatLevel) {
                case 'HIGH': iconColor = '#ef4444'; iconSymbol = '🔥'; break;
                case 'MEDIUM': iconColor = '#f97316'; iconSymbol = '⚠️'; break;
                case 'LOW': iconColor = '#eab308'; iconSymbol = '🔍'; break;
                default: iconColor = '#ef4444'; iconSymbol = '❓';
            }
        } else {
            iconColor = '#3b82f6';
            iconSymbol = '🛡️';
        }

        return { iconColor, iconSymbol };
    }
}