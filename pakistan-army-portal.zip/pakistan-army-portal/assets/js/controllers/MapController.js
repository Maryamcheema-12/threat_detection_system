class MapController {
    constructor() {
        this.map = null;
        this.markers = [];
    }

    initializeMap() {
        setTimeout(() => {
            try {
                if (this.map) this.map.remove();

                this.map = L.map('map', {
                    center: CONFIG.MAP.CENTER,
                    zoom: CONFIG.MAP.ZOOM,
                    zoomControl: true
                });

                L.tileLayer(CONFIG.MAP.TILE_URL, {
                    attribution: CONFIG.MAP.ATTRIBUTION
                }).addTo(this.map);

                this.map.invalidateSize();

                setTimeout(() => {
                    this.addKNNEnhancedMarkers();
                }, 500);

            } catch (error) {
                console.error('Map error:', error);
                document.getElementById('map').innerHTML = `
                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: white; text-align: center; flex-direction: column;">
                        <div style="font-size: 48px; margin-bottom: 20px;">🤖</div>
                        <div style="font-size: 20px; color: #8b5cf6;">KNN TACTICAL MAP</div>
                        <div style="font-size: 16px; margin: 20px 0;">AI-Enhanced Punjab Region</div>
                    </div>
                `;
            }
        }, 200);
    }

    addKNNEnhancedMarkers() {
        if (!this.map || !window.enhancedThreatDetector) return;

        const locations = DataModels.getMapLocations();

        locations.forEach((loc, index) => {
            try {
                const enhancedData = { ...loc, timeOfDay: new Date().getHours(), direction: Math.random() * 360 };
                const knnAnalysis = window.enhancedThreatDetector.hybridClassification(enhancedData);
                
                const { iconColor, iconSymbol } = Helpers.getIconConfig(knnAnalysis.finalThreat, loc.type);

                const customIcon = L.divIcon({
                    html: `<div style="
                        background: ${iconColor}; 
                        width: 30px; height: 30px; 
                        border-radius: 50%; 
                        border: 3px solid white;
                        display: flex; align-items: center; justify-content: center;
                        font-size: 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);
                    ">${iconSymbol}</div>`,
                    iconSize: [36, 36],
                    iconAnchor: [18, 18]
                });

                const marker = L.marker([loc.lat, loc.lng], { icon: customIcon }).addTo(this.map);
                
                marker.bindPopup(ComponentRenderer.renderMapPopup(loc, knnAnalysis, iconColor, iconSymbol));
                
                this.markers.push(marker);

            } catch (error) {
                console.error(`Error adding marker ${index}:`, error);
            }
        });
    }

    cleanup() {
        if (this.map) {
            this.map.remove();
            this.map = null;
        }
        this.markers = [];
    }
}