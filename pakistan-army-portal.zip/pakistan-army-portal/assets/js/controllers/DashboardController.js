class DashboardController {
    constructor() {
        this.missionStartTime = Date.now();
        this.chart = null;
        this.mapController = new MapController();
        this.init();
    }

    init() {
        // Dashboard controller initialized
    }

    initializeKNNSystem() {
        window.enhancedThreatDetector = new EnhancedThreatDetection();
        console.log('🤖 KNN System initialized');
        
        const knnStatus = document.getElementById('knnStatus');
        if (knnStatus) {
            knnStatus.textContent = '🤖 KNN Online';
        }
    }

    initializeDashboard() {
        this.mapController.initializeMap();
        window.dashboardView.renderThreats();
        window.dashboardView.renderTacticalSuggestions();
        window.dashboardView.renderChat();
        window.dashboardView.renderLogs();
        this.initializeChart();
        this.startMissionTimer();
        this.startRealTimeUpdates();
    }

    initializeChart() {
        const ctx = document.getElementById('statsChart').getContext('2d');
        this.chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['High Threats', 'Medium Threats', 'Low Threats', 'Safe Units'],
                datasets: [{
                    data: [4, 8, 12, 18],
                    backgroundColor: ['#ef4444', '#f97316', '#eab308', '#22c55e'],
                    borderWidth: 2,
                    borderColor: '#1a1a1a'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: 'white',
                            font: { size: 9 }
                        }
                    }
                }
            }
        });
    }

    sendMessage() {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();
        
        if (message) {
            const chatMessages = document.getElementById('chatMessages');
            chatMessages.innerHTML += ComponentRenderer.renderChatMessage({ type: 'user', text: message });
            input.value = '';
            
            setTimeout(() => {
                const aiResponse = '🤖 Message received. KNN analysis indicates normal operational parameters. All systems functioning optimally.';
                chatMessages.innerHTML += ComponentRenderer.renderChatMessage({ type: 'ai', text: aiResponse });
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }, 1000);
            
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }

    startMissionTimer() {
        setInterval(() => {
            const elapsed = Date.now() - this.missionStartTime;
            document.getElementById('missionTimer').textContent = Helpers.formatTime(elapsed);
        }, 1000);
    }

    startRealTimeUpdates() {
        setInterval(() => {
            if (window.enhancedThreatDetector) {
                const scenario = Helpers.generateScenario();
                const result = window.enhancedThreatDetector.hybridClassification(scenario);
                
                if (result.combinedConfidence > 0.75) {
                    const chatMessages = document.getElementById('chatMessages');
                    const alertMessage = `🚨 KNN ALERT: ${result.finalThreat} threat detected. Confidence: ${(result.combinedConfidence * 100).toFixed(1)}%`;
                    chatMessages.innerHTML += ComponentRenderer.renderChatMessage({ type: 'ai', text: alertMessage });
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }
            }
        }, CONFIG.KNN.UPDATE_INTERVAL);
    }

    showNotifications() {
        alert('🔔 KNN NOTIFICATIONS:\n\n🚨 High-confidence threat detected\n✈️ Air support available\n🤖 Machine learning alert\n📡 KNN analysis complete');
    }

    toggleTheme() {
        document.body.classList.toggle('light-theme');
    }
}