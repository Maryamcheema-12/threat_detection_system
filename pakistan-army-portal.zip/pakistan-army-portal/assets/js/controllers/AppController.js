class AppController {
    constructor() {
        this.init();
    }

    init() {
        // Initialize views
        window.landingView = new LandingView();
        window.loginView = new LoginView();
        window.dashboardView = new DashboardView();
        
        // Initialize controllers
        window.authController = new AuthController();
        window.dashboardController = new DashboardController();
        
        // Initialize event manager
        window.eventManager = new EventManager();
        window.eventManager.setupGlobalEvents();
        
        console.log(`
🇵🇰 PAKISTAN ARMY AI THREAT DETECTION SYSTEM
============================================
Status: OPERATIONAL
Technology: K-Nearest Neighbors Algorithm
Team: Nashia Khalid & Inza Ikram
Features: 3D Landing + KNN Dashboard + Real AI
============================================
        `);
    }

    showLogin() {
        document.getElementById('landingPage').classList.add('hidden');
        document.getElementById('loginScreen').classList.add('active');
    }

    logout() {
        if (confirm('Logout from KNN Command Center?')) {
            document.getElementById('dashboard').classList.remove('active');
            document.getElementById('landingPage').classList.remove('hidden');
            
            // Cleanup
            window.dashboardController.mapController.cleanup();
            window.enhancedThreatDetector = null;
        }
    }
}