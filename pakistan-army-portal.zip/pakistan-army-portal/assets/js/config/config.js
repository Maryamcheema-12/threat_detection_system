const CONFIG = {
    APP_NAME: 'Pakistan Army AI Threat Detection System',
    VERSION: '1.0.0',
    
    // Authentication
    AUTH: {
        VALID_EMAIL: 'nashiakhaliddar@gmail.com',
        VALID_PASSWORD: '89488ba4'
    },
    
    // Map Configuration
    MAP: {
        CENTER: [31.5204, 74.3587],
        ZOOM: 8,
        TILE_URL: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        ATTRIBUTION: '© Pakistan Army AI System'
    },
    
    // KNN Configuration
    KNN: {
        K_VALUE: 5,
        UPDATE_INTERVAL: 30000
    },
    
    // UI Configuration
    UI: {
        ANIMATION_DURATION: 300,
        NOTIFICATION_TIMEOUT: 5000
    }
};