class ComponentRenderer {
    static renderThreatItem(threat) {
        return `
            <div class="threat-item">
                <div class="threat-info">
                    <h4>${threat.title}</h4>
                    <p>${threat.location}</p>
                </div>
                <span class="threat-level threat-${threat.level}">${threat.level.toUpperCase()}</span>
            </div>
        `;
    }

    static renderTacticalItem(suggestion) {
        return `
            <div class="tactical-item">
                <h4>${suggestion.title}</h4>
                <p>${suggestion.description}</p>
                <div class="knn-badge">AI Generated</div>
            </div>
        `;
    }

    static renderChatMessage(message) {
        return `<div class="message ${message.type}">${message.text}</div>`;
    }

    static renderLogEntry(log, index, logs) {
        const time = new Date(Date.now() - (logs.length - index) * 30000).toLocaleTimeString();
        const logClass = log.type === 'knn' ? 'log-entry knn-log' : 'log-entry';
        const icon = log.type === 'knn' ? '🤖' : '🔒';
        
        return `
            <div class="${logClass}">
                <span class="log-time">[${time}]</span> ${icon} ${log.message}
            </div>
        `;
    }

    static renderMapPopup(loc, knnAnalysis, iconColor, iconSymbol) {
        const confidence = (knnAnalysis.combinedConfidence * 100).toFixed(1);
        return `
            <div style="color: black; font-size: 13px; min-width: 250px;">
                <div style="background: ${iconColor}; color: white; padding: 10px; margin: -10px -10px 15px -10px; border-radius: 6px;">
                    <strong>${iconSymbol} ${loc.info}</strong>
                </div>
                <strong>📍 Position:</strong> ${loc.lat.toFixed(4)}, ${loc.lng.toFixed(4)}<br>
                <strong>📏 Distance:</strong> ${loc.distance}m<br>
                <strong>🎯 Unit Size:</strong> ${loc.unitSize}<br>
                <div style="background: #f8f9fa; padding: 8px; border-radius: 4px; margin: 10px 0; border-left: 4px solid #8b5cf6;">
                    <strong>🤖 KNN Analysis:</strong><br>
                    <span style="color: ${iconColor}; font-weight: bold;">Final: ${knnAnalysis.finalThreat}</span><br>
                    <small>Confidence: ${confidence}%</small><br>
                    <small>Rule: ${knnAnalysis.ruleBasedResult} | KNN: ${knnAnalysis.knnResult.predictedThreat}</small>
                </div>
            </div>
        `;
    }
}