class DashboardView {
    constructor() {
        this.init();
    }

    init() {
        this.render();
    }

    render() {
        const dashboard = document.getElementById('dashboard');
        dashboard.innerHTML = `
            <nav class="top-nav">
                <div class="nav-left">
                    <div class="logo">🇵🇰 AI THREAT DETECTION SYSTEM</div>
                    <div class="user-info">
                        <div class="user-avatar">N</div>
                        <span class="user-name">Commander Nashia</span>
                    </div>
                </div>
                <div class="nav-right">
                    <div class="knn-status" id="knnStatus">🤖 KNN Active</div>
                    <div class="notification-bell" onclick="dashboardController.showNotifications()">
                        🔔
                        <span class="notification-count">3</span>
                    </div>
                    <button class="theme-toggle" onclick="dashboardController.toggleTheme()">🌙 Dark</button>
                    <button class="logout-btn" onclick="appController.logout()">Logout</button>
                </div>
            </nav>

            <div class="dashboard-container">
                <div class="map-panel">
                    <div class="panel-header">
                        <span class="panel-icon">🗺️</span>
                        <span>Live Tactical Map - Punjab, Pakistan</span>
                        <span class="knn-indicator">KNN Enhanced</span>
                    </div>
                    <div id="map"></div>
                </div>

                <div class="right-sidebar">
                    <div class="threat-panel">
                        <div class="panel-header">
                            <span class="panel-icon">⚠️</span>
                            <span>AI Threat Intelligence</span>
                        </div>
                        <div class="panel-content" id="threatContent"></div>
                    </div>

                    <div class="tactical-panel">
                        <div class="panel-header">
                            <span class="panel-icon">🎯</span>
                            <span>KNN Tactical Recommendations</span>
                        </div>
                        <div class="panel-content" id="tacticalContent"></div>
                    </div>
                </div>
            </div>

            <div class="bottom-stats">
                <div class="stats-panel">
                    <div class="panel-header">
                        <span class="panel-icon">📊</span>
                        <span>Mission & KNN Stats</span>
                    </div>
                    <div class="panel-content">
                        <div class="mission-timer">
                            <div class="timer-display" id="missionTimer">00:00:00</div>
                            <div class="timer-label">Mission Duration</div>
                        </div>
                        <div class="chart-container">
                            <canvas id="statsChart"></canvas>
                        </div>
                    </div>
                </div>

                <div class="chat-panel">
                    <div class="panel-header">
                        <span class="panel-icon">💬</span>
                        <span>AI Command Chat</span>
                    </div>
                    <div class="chat-messages" id="chatMessages"></div>
                    <div class="chat-input">
                        <input type="text" id="chatInput" placeholder="Type your message...">
                        <button onclick="dashboardController.sendMessage()">Send</button>
                    </div>
                </div>

                <div class="logs-panel">
                    <div class="panel-header">
                        <span class="panel-icon">🔒</span>
                        <span>System & KNN Logs</span>
                    </div>
                    <div class="logs-content" id="logsContent"></div>
                </div>
            </div>
        `;
    }

    renderThreats() {
        const threats = DataModels.getThreats();
        const threatContent = document.getElementById('threatContent');
        threatContent.innerHTML = threats.map(threat => 
            ComponentRenderer.renderThreatItem(threat)
        ).join('');
    }

    renderTacticalSuggestions() {
        const suggestions = DataModels.getTacticalSuggestions();
        const tacticalContent = document.getElementById('tacticalContent');
        tacticalContent.innerHTML = suggestions.map(suggestion => 
            ComponentRenderer.renderTacticalItem(suggestion)
        ).join('');
    }

    renderChat() {
        const messages = DataModels.getChatMessages();
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = messages.map(msg => 
            ComponentRenderer.renderChatMessage(msg)
        ).join('');
    }

    renderLogs() {
        const logs = DataModels.getLogs();
        const logsContent = document.getElementById('logsContent');
        logsContent.innerHTML = logs.map((log, index) => 
            ComponentRenderer.renderLogEntry(log, index, logs)
        ).join('');
    }
}