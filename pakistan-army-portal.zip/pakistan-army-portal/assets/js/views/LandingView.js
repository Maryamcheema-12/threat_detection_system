class LandingView {
    constructor() {
        this.init();
    }

    init() {
        this.render();
    }

    render() {
        const landingPage = document.getElementById('landingPage');
        landingPage.innerHTML = `
            <header class="header">
                <a href="#home" class="logo">🇵🇰 PAKISTAN ARMY</a>
                <nav class="nav">
                    <a href="#ai-features">AI Features</a>
                    <a href="#technology">Technology</a>
                    <a href="#security">Security</a>
                    <a href="#about">About</a>
                </nav>
                <div class="auth-section">
                    <button class="btn btn-ghost" onclick="appController.showLogin()">Login</button>
                    <button class="btn btn-primary" onclick="appController.showLogin()">Access System</button>
                </div>
            </header>

            <section id="home" class="main-content">
                <div class="content-wrapper">
                    <div class="text-content">
                        <div class="badge">
                            <span>🇵🇰</span>
                            AI-Powered Defense Technology
                        </div>
                        
                        <h1 class="hero-title">AI THREAT DETECTION<br>SYSTEM</h1>
                        
                        <p class="hero-subtitle">
                            Advanced AI-powered threat detection system with tactical support capabilities. 
                            Utilizing K-Nearest Neighbors machine learning algorithms for real-time battlefield intelligence 
                            and strategic decision support for Pakistan Army operations.
                        </p>
                        
                        <div class="cta-buttons">
                            <button class="btn btn-large btn-outline" onclick="Helpers.scrollToSection('technology')">Learn More →</button>
                            <button class="btn btn-large btn-solid" onclick="appController.showLogin()">Access Dashboard →</button>
                        </div>
                    </div>

                    <div class="scene-container">
                        <div class="robot-model" id="robotModel">
                            <div class="base-platform"></div>
                            <div class="support-stand"></div>
                            <div class="monitor">
                                <div class="screen"></div>
                            </div>
                            <div class="robot-head">
                                <div class="camera-eyes">
                                    <div class="eye"></div>
                                    <div class="eye"></div>
                                </div>
                            </div>
                            <div class="floating-element floating-1"></div>
                            <div class="floating-element floating-2"></div>
                            <div class="floating-element floating-3"></div>
                        </div>
                    </div>
                </div>
            </section>
        `;
    }
}