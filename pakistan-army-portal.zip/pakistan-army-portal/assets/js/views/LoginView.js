class LoginView {
    constructor() {
        this.init();
    }

    init() {
        this.render();
        this.setupEvents();
    }

    render() {
        const loginScreen = document.getElementById('loginScreen');
        loginScreen.innerHTML = `
            <div class="login-container">
                <h2 class="login-title">🇵🇰 SECURE ACCESS</h2>
                <form id="loginForm">
                    <div class="form-group">
                        <label for="email">Service ID / Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Security Code</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <button type="submit" class="login-btn">Access Command Center</button>
                    <div class="error-message" id="errorMessage"></div>
                </form>
            </div>
        `;
        
        // Auto-fill credentials
        setTimeout(() => {
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            if (emailInput && passwordInput) {
                emailInput.value = CONFIG.AUTH.VALID_EMAIL;
                passwordInput.value = CONFIG.AUTH.VALID_PASSWORD;
            }
        }, 100);
    }

    setupEvents() {
        setTimeout(() => {
            const loginForm = document.getElementById('loginForm');
            const loginBtn = document.querySelector('.login-btn');

            if (loginBtn) {
                loginBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.authController.performLogin();
                });
            }

            if (loginForm) {
                loginForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    window.authController.performLogin();
                });
            }
        }, 200);
    }
}