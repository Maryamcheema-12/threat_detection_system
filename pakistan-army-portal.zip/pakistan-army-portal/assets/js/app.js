// Global variables
let appController;

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize main app controller
    appController = new AppController();
    
    // Make controllers globally accessible for onclick handlers
    window.appController = appController;
});

// Console log for system status
console.log('🇵🇰 Pakistan Army AI System - MVC Architecture Loaded');