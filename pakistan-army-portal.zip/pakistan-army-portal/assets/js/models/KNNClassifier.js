class MilitaryKNNClassifier {
    constructor(k = 5) {
        this.k = k;
        this.trainingData = [
            {distance: 450, speed: 35, direction: 180, unitSize: 4, terrain: 'urban', timeOfDay: 14, threatLevel: 'HIGH', confidence: 0.95},
            {distance: 320, speed: 25, direction: 90, unitSize: 2, terrain: 'urban', timeOfDay: 22, threatLevel: 'HIGH', confidence: 0.92},
            {distance: 800, speed: 15, direction: 45, unitSize: 8, terrain: 'rural', timeOfDay: 6, threatLevel: 'MEDIUM', confidence: 0.78},
            {distance: 750, speed: 20, direction: 270, unitSize: 3, terrain: 'rural', timeOfDay: 18, threatLevel: 'MEDIUM', confidence: 0.82},
            {distance: 1200, speed: 10, direction: 135, unitSize: 1, terrain: 'open', timeOfDay: 12, threatLevel: 'LOW', confidence: 0.65},
            {distance: 200, speed: 12, direction: 0, unitSize: 5, terrain: 'base', timeOfDay: 8, threatLevel: 'SAFE', confidence: 0.98}
        ];
        this.isTrained = true;
    }

    extractFeatures(unitData) {
        return {
            distance: unitData.distance || 0,
            speed: unitData.speed || 0,
            direction: unitData.direction || 0,
            unitSize: unitData.unitSize || 1,
            terrain: this.encodeTerrainType(unitData.terrain || 'unknown'),
            timeOfDay: unitData.timeOfDay || new Date().getHours()
        };
    }

    encodeTerrainType(terrain) {
        const terrainMap = {
            'urban': 1, 'suburban': 2, 'rural': 3, 'open': 4, 
            'highway': 5, 'base': 6, 'patrol': 7, 'border': 8, 
            'remote': 9, 'unknown': 0
        };
        return terrainMap[terrain.toLowerCase()] || 0;
    }

    calculateDistance(features1, features2) {
        const weights = {
            distance: 0.3, speed: 0.2, direction: 0.1,
            unitSize: 0.25, terrain: 0.1, timeOfDay: 0.05
        };

        let sum = 0;
        for (let feature in weights) {
            if (features1[feature] !== undefined && features2[feature] !== undefined) {
                sum += weights[feature] * Math.pow(features1[feature] - features2[feature], 2);
            }
        }
        return Math.sqrt(sum);
    }

    classify(unitData) {
        const queryFeatures = this.extractFeatures(unitData);
        
        const distances = this.trainingData.map(trainingSample => {
            const trainingFeatures = this.extractFeatures(trainingSample);
            const distance = this.calculateDistance(queryFeatures, trainingFeatures);
            
            return {
                sample: trainingSample,
                distance: distance,
                threatLevel: trainingSample.threatLevel,
                confidence: trainingSample.confidence
            };
        });

        const nearestNeighbors = distances
            .sort((a, b) => a.distance - b.distance)
            .slice(0, this.k);

        const votes = {};
        let totalWeight = 0;

        nearestNeighbors.forEach(neighbor => {
            const weight = (1 / (neighbor.distance + 0.001)) * neighbor.confidence;
            const threatLevel = neighbor.threatLevel;
            
            if (!votes[threatLevel]) {
                votes[threatLevel] = 0;
            }
            votes[threatLevel] += weight;
            totalWeight += weight;
        });

        for (let level in votes) {
            votes[level] /= totalWeight;
        }

        const predictedThreat = Object.keys(votes).reduce((a, b) => 
            votes[a] > votes[b] ? a : b
        );

        return {
            predictedThreat: predictedThreat,
            confidence: votes[predictedThreat],
            votes: votes
        };
    }

    addTrainingData(newData) {
        this.trainingData.push(newData);
    }

    getModelStats() {
        const threatCounts = {};
        this.trainingData.forEach(sample => {
            threatCounts[sample.threatLevel] = (threatCounts[sample.threatLevel] || 0) + 1;
        });

        return {
            totalSamples: this.trainingData.length,
            kValue: this.k,
            threatDistribution: threatCounts
        };
    }
}