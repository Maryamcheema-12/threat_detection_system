class EnhancedThreatDetection {
    constructor() {
        this.knnClassifier = new MilitaryKNNClassifier(5);
        this.ruleBasedSystem = {
            classify: (distance, type) => {
                if (type === 'enemy' && distance < 500) return 'HIGH';
                if (type === 'enemy' && distance < 1000) return 'MEDIUM';
                if (type === 'enemy') return 'LOW';
                return 'SAFE';
            }
        };
    }

    hybridClassification(unitData) {
        const ruleBasedResult = this.ruleBasedSystem.classify(unitData.distance, unitData.type);
        const knnResult = this.knnClassifier.classify(unitData);
        
        const finalThreat = this.combineClassifications(ruleBasedResult, knnResult.predictedThreat, knnResult.confidence);
        
        return {
            finalThreat: finalThreat,
            ruleBasedResult: ruleBasedResult,
            knnResult: knnResult,
            combinedConfidence: this.calculateCombinedConfidence(ruleBasedResult, knnResult)
        };
    }

    combineClassifications(ruleResult, knnResult, knnConfidence) {
        const threatLevels = {'SAFE': 0, 'LOW': 1, 'MEDIUM': 2, 'HIGH': 3};
        
        const combinedScore = (threatLevels[ruleResult] * 0.4) + 
                             (threatLevels[knnResult] * 0.6 * knnConfidence);
        
        if (combinedScore >= 2.5) return 'HIGH';
        if (combinedScore >= 1.5) return 'MEDIUM'; 
        if (combinedScore >= 0.5) return 'LOW';
        return 'SAFE';
    }

    calculateCombinedConfidence(ruleResult, knnResult) {
        const agreement = ruleResult === knnResult.predictedThreat ? 1.0 : 0.5;
        return (agreement * knnResult.confidence * 0.8) + 0.2;
    }
}