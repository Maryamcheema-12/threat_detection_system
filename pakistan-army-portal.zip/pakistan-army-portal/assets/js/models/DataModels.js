class DataModels {
    static getThreats() {
        return [
            { title: '4 Enemy Tanks Detected', location: 'Lahore Sector', level: 'high' },
            { title: 'Drone Surveillance Active', location: 'Northern Border', level: 'medium' },
            { title: 'Infantry Movement', location: 'Eastern Route', level: 'low' }
        ];
    }

    static getTacticalSuggestions() {
        return [
            { title: 'KNN Priority Alert', description: 'High-confidence threat detected - Deploy response team' },
            { title: 'AI Tactical Analysis', description: 'Pattern suggests flanking maneuver - Reinforce positions' },
            { title: 'Machine Learning Insight', description: 'Historical data indicates 85% probability of night assault' }
        ];
    }

    static getChatMessages() {
        return [
            { type: 'ai', text: '🤖 KNN-Enhanced Command Center online. AI threat detection operational.' },
            { type: 'ai', text: '📊 Machine learning models loaded. K=5 algorithm active.' },
            { type: 'user', text: 'Request tactical update with AI analysis.' },
            { type: 'ai', text: '🎯 KNN Analysis: Multiple hostile signatures detected. High-confidence assessment in progress.' }
        ];
    }

    static getLogs() {
        return [
            { message: 'KNN Threat Detection System initialized', type: 'knn' },
            { message: 'User authenticated: nashiakhaliddar@gmail.com', type: 'system' },
            { message: 'K-Nearest Neighbors algorithm loaded', type: 'knn' },
            { message: 'All systems operational', type: 'system' }
        ];
    }

    static getMapLocations() {
        return [
            { lat: 31.5820, lng: 74.3293, type: 'enemy', info: 'Enemy Tank Unit', 
              distance: 450, speed: 35, unitSize: 4, terrain: 'urban' },
            { lat: 31.4504, lng: 73.1350, type: 'enemy', info: 'Enemy Infantry', 
              distance: 800, speed: 15, unitSize: 20, terrain: 'rural' },
            { lat: 31.1704, lng: 72.7097, type: 'ally', info: 'Allied Base', 
              distance: 0, speed: 0, unitSize: 50, terrain: 'base' }
        ];
    }
}