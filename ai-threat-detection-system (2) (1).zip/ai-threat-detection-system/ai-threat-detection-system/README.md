# AI Threat Detection and Tactical Support System

## Project Overview

This project is an AI-powered threat detection and tactical support system designed for military teams. It uses machine learning algorithms to analyze battlefield parameters and provide intelligent threat assessments and tactical recommendations.

## Features

### Core Functionality
- **AI Threat Assessment**: Uses Random Forest Classifier to analyze battlefield conditions
- **Real-time Analysis**: Processes enemy distance, troop counts, terrain, weather, and time factors
- **Tactical Recommendations**: Provides actionable advice based on threat level assessment
- **User Authentication**: Role-based access control (Commander, Soldier, Analyst)
- **Dashboard Analytics**: Visual representation of threat data and system status

### System Modules
1. **Data Input Module**: Collects battlefield parameters
2. **Threat Detection Module**: ML-powered threat level analysis
3. **Tactical Support Module**: Generates strategic recommendations
4. **User Dashboard**: Real-time overview and analytics
5. **Alert System**: Notification system for critical threats

## Technology Stack

| Component | Technology |
|-----------|------------|
| Frontend | HTML5, CSS3, JavaScript, Chart.js |
| Backend | Node.js, Express.js |
| Database | MongoDB |
| ML/AI | Python, scikit-learn, pandas, numpy |
| Authentication | JWT (JSON Web Tokens) |
| Styling | Custom CSS with military theme |

## Machine Learning Model

The system uses a **Random Forest Classifier** that analyzes:
- Enemy distance (meters)
- Enemy count
- Friendly troop count
- Terrain type (urban, forest, desert, mountain)
- Weather conditions (clear, rain, fog, storm)
- Time of day (day, night)

### Threat Levels
- **Low**: Minimal threat, proceed with caution
- **Medium**: Moderate threat, increase alertness
- **High**: Severe threat, immediate action required

## Installation

### Prerequisites
- Node.js (v14 or higher)
- Python 3.8+
- MongoDB
- npm or yarn

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ai-threat-detection-system
   ```

2. **Install Node.js dependencies**
   ```bash
   npm install
   ```

3. **Install Python dependencies**
   ```bash
   pip3 install -r requirements.txt
   ```

4. **Start MongoDB**
   ```bash
   sudo systemctl start mongod
   ```

5. **Run the application**
   ```bash
   npm start
   # or
   node server.js
   ```

6. **Access the system**
   Open your browser and navigate to `http://localhost:3000`

## Usage

### User Registration
1. Click "Register" on the login screen
2. Fill in your details (Name, Email, Password, Role)
3. Select your role: Commander, Soldier, or Analyst
4. Click "Create Account"

### Threat Assessment
1. Navigate to the "Threat Assessment" section
2. Input battlefield parameters:
   - Enemy distance in meters
   - Number of enemy personnel
   - Number of friendly troops
   - Terrain type
   - Weather conditions
   - Time of day
3. Click "Analyze Threat"
4. Review the AI-generated threat level and recommendations

### Dashboard Features
- **Threat Level Distribution**: Visual chart showing threat assessment history
- **Recent Assessments**: Quick overview of latest analyses
- **System Status**: Real-time system health monitoring
- **Tactical Map**: Strategic overview interface

## API Endpoints

### Authentication
- `POST /api/register` - User registration
- `POST /api/login` - User login
- `GET /api/profile` - Get user profile

### Threat Assessment
- `POST /api/assess-threat` - Analyze threat parameters
- `GET /api/assessments` - Get assessment history
- `GET /api/dashboard-stats` - Get dashboard statistics

### Mission Management
- `POST /api/missions` - Create new mission
- `GET /api/missions` - Get user missions

## File Structure

```
ai-threat-detection-system/
├── public/
│   ├── assets/
│   │   └── images/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── app.js
│   └── index.html
├── ml_models/
│   ├── threat_predictor.py
│   ├── threat_model.pkl (generated)
│   └── encoders.pkl (generated)
├── server.js
├── package.json
├── requirements.txt
└── README.md
```

## Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcrypt encryption for user passwords
- **Role-based Access**: Different access levels for different user roles
- **Input Validation**: Server-side validation for all inputs
- **CORS Protection**: Cross-origin request security

## Future Enhancements

- Real-time camera/drone data integration
- Mobile application for field personnel
- Voice command interface
- Historical data training with real battlefield scenarios
- AI-powered image analysis for enemy detection
- Advanced mapping and GPS integration
- Multi-language support
- Enhanced reporting and analytics

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit your changes (`git commit -am 'Add new feature'`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For technical support or questions, please contact:
- Email: support@aithreatdetection.com
- Documentation: [Project Wiki]
- Issues: [GitHub Issues]

## Acknowledgments

- Developed by Maryam Naveed (G1F22UBSCS175)
- Supervised by Prof. Hamza Afzal
- University of Central Punjab, Faculty of Computer Science
- Fall 2025, Semester VI

---

**Note**: This system is designed for educational and training purposes. For actual military deployment, additional security measures and testing would be required.

