// Global variables
let currentUser = null;
let authToken = null;
let threatChart = null;

// DOM elements
const loginModal = document.getElementById('loginModal');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const navLinks = document.querySelectorAll('.nav-link[data-section]');
const contentSections = document.querySelectorAll('.content-section');
const loadingSpinner = document.getElementById('loadingSpinner');
const alertContainer = document.getElementById('alertContainer');

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    checkAuthStatus();
});

function initializeApp() {
    // Check if user is already logged in
    const token = localStorage.getItem('authToken');
    if (token) {
        authToken = token;
        hideModal();
        loadUserProfile();
        loadDashboardData();
    } else {
        showModal();
    }
}

function setupEventListeners() {
    // Auth form listeners
    setupAuthListeners();
    
    // Navigation listeners
    setupNavigationListeners();
    
    // Assessment form listener
    setupAssessmentListeners();
    
    // Other listeners
    setupMiscListeners();
}

function setupAuthListeners() {
    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tab = this.dataset.tab;
            switchAuthTab(tab);
        });
    });

    // Login form
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        try {
            showLoading();
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                authToken = data.token;
                currentUser = data.user;
                localStorage.setItem('authToken', authToken);
                hideModal();
                hideLoading();
                showAlert('Login successful', 'success');
                loadUserProfile();
                loadDashboardData();
            } else {
                hideLoading();
                showAlert(data.error || 'Login failed', 'error');
            }
        } catch (error) {
            hideLoading();
            showAlert('Network error. Please try again.', 'error');
        }
    });

    // Register form
    registerForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        const role = document.getElementById('registerRole').value;
        
        try {
            showLoading();
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ name, email, password, role })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                authToken = data.token;
                currentUser = data.user;
                localStorage.setItem('authToken', authToken);
                hideModal();
                hideLoading();
                showAlert('Registration successful', 'success');
                loadUserProfile();
                loadDashboardData();
            } else {
                hideLoading();
                showAlert(data.error || 'Registration failed', 'error');
            }
        } catch (error) {
            hideLoading();
            showAlert('Network error. Please try again.', 'error');
        }
    });
}

function setupNavigationListeners() {
    // Navigation menu
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.dataset.section;
            showSection(section);
            
            // Update active nav link
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Mobile menu toggle
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    
    if (navToggle) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        logout();
    });
}

function setupAssessmentListeners() {
    const assessmentForm = document.getElementById('assessmentForm');
    
    assessmentForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = {
            enemyDistance: document.getElementById('enemyDistance').value,
            enemyCount: document.getElementById('enemyCount').value,
            troopCount: document.getElementById('troopCount').value,
            terrain: document.getElementById('terrain').value,
            weather: document.getElementById('weather').value,
            timeOfDay: document.getElementById('timeOfDay').value
        };
        
        try {
            showLoading();
            const response = await fetch('/api/assess-threat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${authToken}`
                },
                body: JSON.stringify(formData)
            });
            
            const data = await response.json();
            hideLoading();
            
            if (response.ok) {
                displayAssessmentResult(data);
                showAlert('Threat assessment completed', 'success');
            } else {
                showAlert(data.error || 'Assessment failed', 'error');
            }
        } catch (error) {
            hideLoading();
            showAlert('Network error. Please try again.', 'error');
        }
    });
}

function setupMiscListeners() {
    // Save assessment button
    document.addEventListener('click', function(e) {
        if (e.target.id === 'saveAssessment') {
            showAlert('Assessment saved to history', 'success');
            loadAssessmentHistory();
        }
    });

    // Create mission button
    const createMissionBtn = document.getElementById('createMissionBtn');
    if (createMissionBtn) {
        createMissionBtn.addEventListener('click', function() {
            const name = prompt('Enter mission name:');
            const description = prompt('Enter mission description:');
            
            if (name && description) {
                createMission(name, description);
            }
        });
    }
}

// Authentication functions
function switchAuthTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelectorAll('.auth-form').forEach(form => {
        form.classList.remove('active');
    });
    
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
    document.getElementById(`${tab}Form`).classList.add('active');
}

function checkAuthStatus() {
    const token = localStorage.getItem('authToken');
    if (!token) {
        showModal();
    }
}

function logout() {
    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    showModal();
    showAlert('Logged out successfully', 'success');
}

// UI functions
function showModal() {
    loginModal.style.display = 'flex';
}

function hideModal() {
    loginModal.style.display = 'none';
}

function showLoading() {
    loadingSpinner.classList.remove('hidden');
}

function hideLoading() {
    loadingSpinner.classList.add('hidden');
}

function showSection(sectionId) {
    contentSections.forEach(section => {
        section.classList.remove('active');
    });
    
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        
        // Load section-specific data
        switch(sectionId) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'history':
                loadAssessmentHistory();
                break;
            case 'missions':
                loadMissions();
                break;
            case 'profile':
                loadUserProfile();
                break;
        }
    }
}

function showAlert(message, type = 'success') {
    const alert = document.createElement('div');
    alert.className = `alert ${type}`;
    alert.textContent = message;
    
    alertContainer.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

// Data loading functions
async function loadUserProfile() {
    try {
        const response = await fetch('/api/profile', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            updateProfileDisplay(data.user);
        }
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

async function loadDashboardData() {
    try {
        const response = await fetch('/api/dashboard-stats', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            updateDashboard(data);
        }
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

async function loadAssessmentHistory() {
    try {
        const response = await fetch('/api/assessments', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const assessments = await response.json();
            displayAssessmentHistory(assessments);
        }
    } catch (error) {
        console.error('Error loading history:', error);
    }
}

async function loadMissions() {
    try {
        const response = await fetch('/api/missions', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const missions = await response.json();
            displayMissions(missions);
        }
    } catch (error) {
        console.error('Error loading missions:', error);
    }
}

async function createMission(name, description) {
    try {
        const response = await fetch('/api/missions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ name, description })
        });
        
        if (response.ok) {
            showAlert('Mission created successfully', 'success');
            loadMissions();
        } else {
            const data = await response.json();
            showAlert(data.error || 'Failed to create mission', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
}

// Display functions
function updateProfileDisplay(user) {
    document.getElementById('profileName').textContent = user.name;
    document.getElementById('profileEmail').textContent = user.email;
    document.getElementById('profileRole').textContent = user.role.toUpperCase();
}

function updateDashboard(data) {
    // Update total assessments
    document.getElementById('totalAssessments').textContent = data.totalAssessments;
    
    // Update threat level chart
    updateThreatChart(data.threatLevelCounts);
    
    // Update recent assessments
    displayRecentAssessments(data.recentAssessments);
}

function updateThreatChart(threatLevelCounts) {
    const ctx = document.getElementById('threatChart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (threatChart) {
        threatChart.destroy();
    }
    
    const labels = [];
    const data = [];
    const colors = [];
    
    threatLevelCounts.forEach(item => {
        labels.push(item._id);
        data.push(item.count);
        
        switch(item._id) {
            case 'Low':
                colors.push('#00ff00');
                break;
            case 'Medium':
                colors.push('#ffa500');
                break;
            case 'High':
                colors.push('#ff4444');
                break;
            default:
                colors.push('#00ff88');
        }
    });
    
    threatChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors,
                borderColor: '#1a1a2e',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: {
                        color: '#e0e0e0'
                    }
                }
            }
        }
    });
}

function displayRecentAssessments(assessments) {
    const container = document.getElementById('recentAssessments');
    
    if (assessments.length === 0) {
        container.innerHTML = '<p style="color: #888; text-align: center;">No recent assessments</p>';
        return;
    }
    
    container.innerHTML = assessments.map(assessment => `
        <div class="assessment-item" style="padding: 10px; margin-bottom: 10px; background: rgba(255,255,255,0.05); border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span class="threat-level ${assessment.threatLevel}" style="padding: 2px 8px; border-radius: 12px; font-size: 0.8rem; font-weight: 600;">
                    ${assessment.threatLevel}
                </span>
                <span style="color: #888; font-size: 0.8rem;">
                    ${new Date(assessment.createdAt).toLocaleDateString()}
                </span>
            </div>
            <p style="margin: 5px 0 0 0; font-size: 0.85rem; color: #b0b0b0;">
                ${assessment.recommendation.substring(0, 60)}...
            </p>
        </div>
    `).join('');
}

function displayAssessmentResult(result) {
    const resultContainer = document.getElementById('assessmentResult');
    
    document.getElementById('threatLevel').textContent = result.threatLevel;
    document.getElementById('threatLevel').className = `threat-value ${result.threatLevel}`;
    
    document.getElementById('confidence').textContent = `${(result.confidence * 100).toFixed(1)}%`;
    document.getElementById('recommendation').textContent = result.recommendation;
    
    document.querySelector('.result-timestamp').textContent = new Date().toLocaleString();
    
    resultContainer.classList.remove('hidden');
    resultContainer.scrollIntoView({ behavior: 'smooth' });
}

function displayAssessmentHistory(assessments) {
    const container = document.getElementById('historyList');
    
    if (assessments.length === 0) {
        container.innerHTML = '<p style="color: #888; text-align: center; padding: 40px;">No assessment history found</p>';
        return;
    }
    
    container.innerHTML = assessments.map(assessment => `
        <div class="history-item">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <span class="threat-level ${assessment.threatLevel}" style="padding: 5px 12px; border-radius: 15px; font-weight: 600;">
                    ${assessment.threatLevel} Threat
                </span>
                <span style="color: #888;">
                    ${new Date(assessment.createdAt).toLocaleString()}
                </span>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 15px; font-size: 0.9rem;">
                <div><strong>Enemy Distance:</strong> ${assessment.enemyDistance}m</div>
                <div><strong>Enemy Count:</strong> ${assessment.enemyCount}</div>
                <div><strong>Troop Count:</strong> ${assessment.troopCount}</div>
                <div><strong>Terrain:</strong> ${assessment.terrain}</div>
                <div><strong>Weather:</strong> ${assessment.weather}</div>
                <div><strong>Time:</strong> ${assessment.timeOfDay}</div>
            </div>
            <div style="background: rgba(0,255,136,0.1); padding: 15px; border-radius: 8px; border-left: 3px solid #00ff88;">
                <strong style="color: #00ff88;">Recommendation:</strong>
                <p style="margin: 5px 0 0 0; line-height: 1.4;">${assessment.recommendation}</p>
            </div>
        </div>
    `).join('');
}

function displayMissions(missions) {
    const container = document.getElementById('missionsList');
    
    if (missions.length === 0) {
        container.innerHTML = '<p style="color: #888; text-align: center; padding: 40px;">No missions found</p>';
        return;
    }
    
    container.innerHTML = missions.map(mission => `
        <div class="mission-item">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h3 style="color: #00ff88; margin: 0;">${mission.name}</h3>
                <span style="background: rgba(0,255,136,0.2); color: #00ff88; padding: 3px 10px; border-radius: 12px; font-size: 0.8rem; text-transform: uppercase;">
                    ${mission.status}
                </span>
            </div>
            <p style="color: #b0b0b0; margin-bottom: 10px; line-height: 1.4;">
                ${mission.description}
            </p>
            <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.85rem; color: #888;">
                <span>Assessments: ${mission.threatAssessments.length}</span>
                <span>Created: ${new Date(mission.createdAt).toLocaleDateString()}</span>
            </div>
        </div>
    `).join('');
}

