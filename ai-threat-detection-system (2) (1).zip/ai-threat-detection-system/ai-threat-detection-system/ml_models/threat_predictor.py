#!/usr/bin/env python3
import sys
import json
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import pickle
import os

class ThreatPredictor:
    def __init__(self):
        self.model = None
        self.label_encoders = {}
        self.model_path = 'ml_models/threat_model.pkl'
        self.encoders_path = 'ml_models/encoders.pkl'
        
        # Initialize or load model
        if os.path.exists(self.model_path) and os.path.exists(self.encoders_path):
            self.load_model()
        else:
            self.train_model()
    
    def create_training_data(self):
        """Create synthetic training data based on the prototype"""
        np.random.seed(42)
        
        # Generate synthetic battlefield data
        data = []
        
        # Define scenarios
        terrains = ['urban', 'forest', 'desert', 'mountain']
        weathers = ['clear', 'rain', 'fog', 'storm']
        times = ['day', 'night']
        
        for _ in range(1000):
            enemy_distance = np.random.uniform(50, 2000)  # meters
            enemy_count = np.random.randint(1, 50)
            troop_count = np.random.randint(5, 100)
            terrain = np.random.choice(terrains)
            weather = np.random.choice(weathers)
            time_of_day = np.random.choice(times)
            
            # Calculate threat level based on rules
            threat_score = 0
            
            # Distance factor
            if enemy_distance < 100:
                threat_score += 3
            elif enemy_distance < 500:
                threat_score += 2
            else:
                threat_score += 1
            
            # Enemy count factor
            if enemy_count > troop_count * 1.5:
                threat_score += 3
            elif enemy_count > troop_count:
                threat_score += 2
            else:
                threat_score += 1
            
            # Terrain factor
            if terrain in ['urban', 'forest']:
                threat_score += 1
            
            # Weather factor
            if weather in ['fog', 'storm']:
                threat_score += 1
            
            # Time factor
            if time_of_day == 'night':
                threat_score += 1
            
            # Determine threat level
            if threat_score <= 4:
                threat_level = 'Low'
            elif threat_score <= 7:
                threat_level = 'Medium'
            else:
                threat_level = 'High'
            
            data.append({
                'enemy_distance': enemy_distance,
                'enemy_count': enemy_count,
                'troop_count': troop_count,
                'terrain': terrain,
                'weather': weather,
                'time_of_day': time_of_day,
                'threat_level': threat_level
            })
        
        return pd.DataFrame(data)
    
    def train_model(self):
        """Train the Random Forest model"""
        # Create training data
        df = self.create_training_data()
        
        # Prepare features
        categorical_features = ['terrain', 'weather', 'time_of_day']
        
        # Encode categorical variables
        for feature in categorical_features:
            le = LabelEncoder()
            df[feature + '_encoded'] = le.fit_transform(df[feature])
            self.label_encoders[feature] = le
        
        # Prepare feature matrix
        feature_columns = ['enemy_distance', 'enemy_count', 'troop_count', 
                          'terrain_encoded', 'weather_encoded', 'time_of_day_encoded']
        X = df[feature_columns]
        y = df['threat_level']
        
        # Train Random Forest model
        self.model = RandomForestClassifier(
            n_estimators=100,
            random_state=42,
            max_depth=10,
            min_samples_split=5
        )
        self.model.fit(X, y)
        
        # Save model and encoders
        self.save_model()
    
    def save_model(self):
        """Save the trained model and encoders"""
        with open(self.model_path, 'wb') as f:
            pickle.dump(self.model, f)
        
        with open(self.encoders_path, 'wb') as f:
            pickle.dump(self.label_encoders, f)
    
    def load_model(self):
        """Load the trained model and encoders"""
        with open(self.model_path, 'rb') as f:
            self.model = pickle.load(f)
        
        with open(self.encoders_path, 'rb') as f:
            self.label_encoders = pickle.load(f)
    
    def predict(self, input_data):
        """Make threat prediction"""
        # Encode categorical features
        encoded_data = input_data.copy()
        
        for feature in ['terrain', 'weather', 'time_of_day']:
            if feature in self.label_encoders:
                try:
                    encoded_data[feature + '_encoded'] = self.label_encoders[feature].transform([input_data[feature]])[0]
                except ValueError:
                    # Handle unknown categories
                    encoded_data[feature + '_encoded'] = 0
        
        # Prepare feature vector
        features = [
            encoded_data['enemy_distance'],
            encoded_data['enemy_count'],
            encoded_data['troop_count'],
            encoded_data['terrain_encoded'],
            encoded_data['weather_encoded'],
            encoded_data['time_of_day_encoded']
        ]
        
        # Make prediction
        prediction = self.model.predict([features])[0]
        confidence = max(self.model.predict_proba([features])[0])
        
        # Generate recommendation
        recommendation = self.generate_recommendation(prediction, input_data)
        
        return {
            'threat_level': prediction,
            'confidence': float(confidence),
            'recommendation': recommendation
        }
    
    def generate_recommendation(self, threat_level, input_data):
        """Generate tactical recommendation based on threat level"""
        recommendations = {
            'Low': [
                "Proceed with caution",
                "Maintain current formation",
                "Continue surveillance",
                "Advance as planned"
            ],
            'Medium': [
                "Increase alertness level",
                "Consider alternative routes",
                "Request additional support",
                "Prepare defensive positions"
            ],
            'High': [
                "Immediate retreat recommended",
                "Call for backup immediately",
                "Take defensive positions",
                "Avoid engagement if possible"
            ]
        }
        
        base_recommendation = np.random.choice(recommendations[threat_level])
        
        # Add specific tactical advice based on conditions
        if input_data['enemy_count'] > input_data['troop_count']:
            base_recommendation += ". Enemy outnumbers friendly forces."
        
        if input_data['enemy_distance'] < 200:
            base_recommendation += " Enemy is in close proximity."
        
        if input_data['weather'] in ['fog', 'storm']:
            base_recommendation += " Weather conditions limit visibility."
        
        return base_recommendation

def main():
    try:
        # Accept input from command line argument or stdin
        if len(sys.argv) == 2:
            input_json = sys.argv[1]
        else:
            # Read from stdin
            input_json = sys.stdin.read()
            if not input_json.strip():
                print(json.dumps({
                    'error': 'Input data required',
                    'threat_level': 'Medium',
                    'confidence': 0.5,
                    'recommendation': 'System error - proceed with caution'
                }), file=sys.stderr, flush=True)
                sys.exit(1)

        input_data = json.loads(input_json)

        # Initialize predictor
        predictor = ThreatPredictor()

        # Make prediction
        result = predictor.predict(input_data)

        # Output result as JSON
        print(json.dumps(result), flush=True)

    except Exception as e:
        error_result = {
            'error': str(e),
            'threat_level': 'Medium',
            'confidence': 0.5,
            'recommendation': 'System error - proceed with caution'
        }
        print(json.dumps(error_result), file=sys.stderr, flush=True)
        sys.exit(1)

if __name__ == "__main__":
    main()

