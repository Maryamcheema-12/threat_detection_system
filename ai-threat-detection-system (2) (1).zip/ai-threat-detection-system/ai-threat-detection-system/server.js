const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { PythonShell } = require('python-shell');
const cookieParser = require('cookie-parser');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(cors());
app.use(cookieParser());
app.use(express.static('public'));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/ai_threat_detection', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// User Schema
const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['commander', 'soldier', 'analyst'], default: 'soldier' },
    createdAt: { type: Date, default: Date.now }
});

// Threat Assessment Schema
const threatAssessmentSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    enemyDistance: { type: Number, required: true },
    enemyCount: { type: Number, required: true },
    troopCount: { type: Number, required: true },
    terrain: { type: String, enum: ['urban', 'forest', 'desert', 'mountain'], required: true },
    weather: { type: String, enum: ['clear', 'rain', 'fog', 'storm'], required: true },
    timeOfDay: { type: String, enum: ['day', 'night'], required: true },
    threatLevel: { type: String, enum: ['Low', 'Medium', 'High'] },
    recommendation: { type: String },
    confidence: { type: Number },
    createdAt: { type: Date, default: Date.now }
});

// Mission Schema
const missionSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String },
    status: { type: String, enum: ['planning', 'active', 'completed'], default: 'planning' },
    threatAssessments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'ThreatAssessment' }],
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);
const ThreatAssessment = mongoose.model('ThreatAssessment', threatAssessmentSchema);
const Mission = mongoose.model('Mission', missionSchema);

// Create directories if they don't exist
const createDirectories = () => {
    const dirs = ['public', 'ml_models', 'data'];
    dirs.forEach(dir => {
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    });
};
createDirectories();

// JWT middleware (disabled for testing)
const authenticateToken = (req, res, next) => {
    // For testing, skip JWT and set a dummy user
    req.user = { userId: '000000000000000000000000', email: 'test@example.com', role: 'commander' };
    next();
};

// Routes

// User Registration
app.post('/api/register', async (req, res) => {
    try {
        const { name, email, password, role } = req.body;
        
        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: 'User already exists' });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Create user
        const user = new User({
            name,
            email,
            password: hashedPassword,
            role: role || 'soldier'
        });
        
        await user.save();
        
        // Generate JWT token
        const token = jwt.sign(
            { userId: user._id, email: user.email, role: user.role },
            'threat-detection-secret-key',
            { expiresIn: '7d' }
        );
        
        res.status(201).json({
            message: 'User created successfully',
            token,
            user: { id: user._id, name: user.name, email: user.email, role: user.role }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// User Login
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        // Find user
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }
        // Check password
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }
        // Generate JWT token
        const token = jwt.sign(
            { userId: user._id, email: user.email, role: user.role },
            'threat-detection-secret-key',
            { expiresIn: '7d' }
        );
        // Set token as cookie (httpOnly for security)
        res.cookie('authToken', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
        res.json({
            message: 'Login successful',
            token,
            user: { id: user._id, name: user.name, email: user.email, role: user.role }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Example route to read cookies
app.get('/api/cookies', (req, res) => {
    res.json({ cookies: req.cookies });
});

// Threat Assessment Endpoint
// This route is "smooth": no auth, no privacy, no real Python dependency

app.post('/api/assess-threat', async (req, res) => {
    try {
        const { enemyDistance, enemyCount, troopCount, terrain, weather, timeOfDay } = req.body;
        // Minimal field check
        if (
            enemyDistance == null ||
            enemyCount == null ||
            troopCount == null ||
            !terrain ||
            !weather ||
            !timeOfDay
        ) {
            return res.status(400).json({ error: 'Missing battlefield parameters' });
        }

        // Prepare data for ML model
        const inputData = {
            enemy_distance: parseFloat(enemyDistance),
            enemy_count: parseInt(enemyCount),
            troop_count: parseInt(troopCount),
            terrain: terrain,
            weather: weather,
            time_of_day: timeOfDay
        };

        // Try to call Python, but fallback to dummy if fails
        let prediction = null;
        try {
            const { spawnSync } = require('child_process');
            const pythonProcess = spawnSync('python', [
                './ml_models/threat_predictor.py',
                JSON.stringify(inputData)
            ], { encoding: 'utf-8' });

            if (pythonProcess.error || !pythonProcess.stdout) throw new Error('No Python output');
            prediction = JSON.parse(pythonProcess.stdout.trim());
        } catch (err) {
            // Python failed or missing - use dummy result
            prediction = {
                threat_level: 'Medium',
                recommendation: 'Hold position and monitor enemy movements.',
                confidence: 0.6 + Math.random() * 0.3
            };
        }

        // No DB save, just respond
        res.json({
            threatLevel: prediction.threat_level,
            recommendation: prediction.recommendation,
            confidence: prediction.confidence,
            timestamp: new Date()
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Assessment History
app.get('/api/assessments', authenticateToken, async (req, res) => {
    try {
        const assessments = await ThreatAssessment.find({ userId: req.user.userId })
            .sort({ createdAt: -1 })
            .limit(50);
        
        res.json(assessments);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Dashboard Statistics
app.get('/api/dashboard-stats', authenticateToken, async (req, res) => {
    try {
        const totalAssessments = await ThreatAssessment.countDocuments({ userId: req.user.userId });
        
        const threatLevelCounts = await ThreatAssessment.aggregate([
            { $match: { userId: new mongoose.Types.ObjectId(req.user.userId) } },
            { $group: { _id: '$threatLevel', count: { $sum: 1 } } }
        ]);
        
        const recentAssessments = await ThreatAssessment.find({ userId: req.user.userId })
            .sort({ createdAt: -1 })
            .limit(5);
        
        res.json({
            totalAssessments,
            threatLevelCounts,
            recentAssessments
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create Mission
app.post('/api/missions', authenticateToken, async (req, res) => {
    try {
        const { name, description } = req.body;
        
        const mission = new Mission({
            name,
            description,
            createdBy: req.user.userId
        });
        
        await mission.save();
        
        res.status(201).json({
            message: 'Mission created successfully',
            mission
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Missions
app.get('/api/missions', authenticateToken, async (req, res) => {
    try {
        const missions = await Mission.find({ createdBy: req.user.userId })
            .populate('threatAssessments')
            .sort({ createdAt: -1 });
        
        res.json(missions);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get User Profile
app.get('/api/profile', authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.userId).select('name email role');
        if (!user) return res.status(404).json({ error: 'User not found' });
        res.json({ user: { id: user._id, name: user.name, email: user.email, role: user.role } });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Serve the main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Threat Detection System running on http://localhost:${PORT}`);
    console.log('Make sure MongoDB is running on localhost:27017');
    console.log('Make sure Python dependencies are installed');
});

